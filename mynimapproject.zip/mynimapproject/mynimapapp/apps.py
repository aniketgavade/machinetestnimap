from django.apps import AppConfig


class MynimapappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mynimapapp'
